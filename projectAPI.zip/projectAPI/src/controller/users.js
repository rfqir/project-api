const getAllUsers = (req, res) => {
    const data = {
        id: "1",
        name: "madrid",
        email: "madrid@gmail.com"
    }

    res.json({
        massage: "GET User Success",
        data: data
    })
}

const createNewUsers = (req, res) => {
    console.log(req.body);
    res.json({
        massage: "Create User Success",
        data: req.body
    })
}

const updateUser = (req, res) => {
    const {id} = req.params;
    console.log('idUser:', id);
    res.json({
        message: "Update User Success",
        data: req.body
    })
}

const deleteUser = (req, res) => {
    const {id} = req.params;
    res.json({
        message: 'DELETE User Success',
        data: {
            id: id,
            name: "Rofiq",
            email: "rofiq@gmail.com"
        }
    })
}

module.exports = {
    getAllUsers,
    createNewUsers,
    updateUser,
    deleteUser
}