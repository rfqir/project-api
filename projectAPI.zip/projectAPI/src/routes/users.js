const express = require('express');
const routes = express();
const userController = require('../controller/users');

//Get atau Selet
routes.get("/", userController.getAllUsers);

//Create - POST
routes.post("/", userController.createNewUsers);

//Update - PATCH
routes.patch("/:id", userController.updateUser);

//DELETE - DELETE
routes.delete("/:id", userController.deleteUser);

module.exports = routes;