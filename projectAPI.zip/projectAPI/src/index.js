const express = require('express');
const app = express();
const userRoutes = require('./routes/users');
const middlewareLogRequest = require('./middleware/logs');
const mysql = require('mysql2');

app.use(middlewareLogRequest);

const db = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "testAPI"
})

app.use(express.json());

app.use("/user", userRoutes);

app.use("/", (req, res) => {
    db.execute('SELECT * FROM user_api', (err, rows) => {
        if(err){
            res.json({
                message: 'connection failed'
            })
        }

        res.json({
            message: 'connection success',
            data: rows
        })
    })
})

app.patch("/", (req, res) => {
    res.send('PATCH API terhubung');
})

app.listen(5000, () => {
    console.log('Server berhasil terhubung');
})